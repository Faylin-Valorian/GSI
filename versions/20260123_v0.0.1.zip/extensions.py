from flask_sqlalchemy import SQLAlchemy

# Initialize the database object here, decoupled from the app
db = SQLAlchemy()